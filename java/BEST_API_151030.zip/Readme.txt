Biomedical Entity Search Tool JAVA API


API Page URL
http://infos.korea.ac.kr/BEST_API

BEST Web version URL
http://best.korea.ac.kr

[Preliminary stage]
1. add json_simple-1.1.jar to build path
2. add BEST_API_yymmdd.jar to build path

